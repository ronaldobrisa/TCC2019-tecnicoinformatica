<?php 
# Inclui o arquivo de conexão
include ('conexao.php');  
# comando SQL do banco 
$sql = "INSERT INTO ordem_servico
      VALUES (0,'$_POST[login_cpf]',
      $_POST[descricao_ordem_servico]',
      $_POST[data_solic_ordem_servico]',
      $_POST[status_ordem_servico]',
      $_POST[id_responsavel_tecnico]')"; 
# Executa a consulta da variável
$query = mysqli_query($conexao,$sql);
if ($query) 
include ('closereload.inc.php');
else echo "Erro ao inserir o registro. Provavelmente o registro já está cadastrado";
?>